import React,{Component} from 'react';
import {variables} from './variables.js';

export class PointOfContact extends Component{
    constructor(props){
        super(props);

        this.state={
            contacts:[]
            
        }
    }

    refreshList(){
        fetch(variables.API_URL+'contacts')
        .then(response=>response.json())
        .then(data=>{
            this.setState({contacts:data});
        });
    }

    componentDidMount(){
        this.refreshList();
    }

    render(){
        const{
            contacts,
            modalTitle,
            pcID,
            patientID,
            firstName,
            lastName,
            phoneNo,
            emailAddress
            // getRowId = params => params.data.id
        }=this.state;
        return(
            <div>
                <table className = "table table-striped">
                    <thead>
                        <th>
                            Contact Id
                        </th>
                        <th>
                            Patient Id
                        </th>
                        <th>
                            First Name
                        </th>
                        <th>
                            Last Name
                        </th>
                        <th>
                            Phone No
                        </th>
                        <th>
                            Email
                        </th>
                       
                    </thead>
                    <tbody>
                        {contacts.map(con=>
                            <tr key ={con.pcID}> 
                            <td>{con.pcID}</td>
                            <td>{con.patientID}</td>
                            <td>{con.firstName}</td>
                            <td>{con.lastName}</td>
                            <td>{con.phoneNo}</td>
                            <td>{con.emailAddress}</td>
                            </tr>)}
                    </tbody>
                </table>

                <div className="modal fade" id="exampleModal" tabIndex="-1" aria-hidden="true">
<div className="modal-dialog modal-lg modal-dialog-centered">
<div className="modal-content">
   <div className="modal-header">
       <h5 className="modal-title">{modalTitle}</h5>
       <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"
       ></button>
   </div>
{/* 
   <div className="modal-body">
       <div className="mb-3">
        <span className="input-group-text">First Name</span>
        <input type="text" className="form-control"
        value={firstName}
        onChange={this.changeFirstName}/>
        <br></br>
        <span className="input-group-text">Last Name</span>
        <input type="text" className="form-control"
        value={lastName}
        onChange={this.changeLastName}/>
        <br></br>
        <span className="input-group-text">DOB</span>
        <input type="text" className="form-control"
        value={dob}
        onChange={this.changeDOB}/>
        <br></br>
        <span className="input-group-text">Street</span>
        <input type="text" className="form-control"
        value={street}
        onChange={this.changeStreet}/>
        <br></br>
        <span className="input-group-text">City</span>
        <input type="text" className="form-control"
        value={city}
        onChange={this.changeCity}/>
        <br></br>
        <span className="input-group-text">State</span>
        <input type="text" className="form-control"
        value={state}
        onChange={this.changeState}/>
        <br></br>
        <span className="input-group-text">Zip Code</span>
        <input type="text" className="form-control"
        value={zipCode}
        onChange={this.changeZipCode}/>
        <br></br>
        <span className="input-group-text">Phone No</span>
        <input type="text" className="form-control"
        value={phoneNo}
        onChange={this.changePhoneNo}/>
        <br></br>
        <span className="input-group-text">Email Address</span>
        <input type="text" className="form-control"
        value={emailAddress}
        onChange={this.changeEmailAddress}/>
       </div>

        {patientID==0?
        <button type="button"
        className="btn btn-primary float-start"
        onClick={()=>this.createClick()}
        >Create</button>
        :null}

        {patientID!=0?
        <button type="button"
        className="btn btn-primary float-start"
        onClick={()=>this.updateClick(patientID)}
        >Update</button>
        :null}

   </div> */}

</div>
</div> 
</div>
            </div>
        )
    }

}