import React,{Component} from 'react';
import {variables} from './variables.js';

export class Patients extends Component{

    constructor(props){
        super(props);

        this.state={
            patients:[],
            PatientIDFilter:"",
            PatientStateFilter:"",
            patientsWithoutFilter:[]
        }
    }
    
    
     
    FilterFn(){
        var PatientIDFilter=this.state.PatientIDFilter;
        var PatientStateFilter = this.state.PatientStateFilter;

        var filteredData=this.state.patientsWithoutFilter.filter(
            function(el){
                return el.patientID.toString().toLowerCase().includes(
                    PatientIDFilter.toString().trim().toLowerCase()
                )&&
                el.state.toString().toLowerCase().includes(
                    PatientStateFilter.toString().trim().toLowerCase()
                )
            }
        );

        this.setState({patients:filteredData});

    }

    sortResult(prop,asc){
        var sortedData=this.state.patientsWithoutFilter.sort(function(a,b){
            if(asc){
                return (a[prop]>b[prop])?1:((a[prop]<b[prop])?-1:0);
            }
            else{
                return (b[prop]>a[prop])?1:((b[prop]<a[prop])?-1:0);
            }
        });

        this.setState({patients:sortedData});
    }

    changePatientIDFilter = (e)=>{
        this.state.PatientIDFilter=e.target.value;
        this.FilterFn();
    }
    changePatientStateFilter = (e)=>{
        this.state.PatientStateFilter=e.target.value;
        this.FilterFn();
    }

    refreshList(){
        fetch(variables.API_URL+'patients')
        .then(response=>response.json())
        .then(data=>{
            this.setState({patients:data,patientsWithoutFilter:data});
        });
    }


    componentDidMount(){
        this.refreshList();
    }

    changeFirstName =(e)=>{
        this.setState({firstName:e.target.value});
    }

    changeLastName =(e)=>{
        this.setState({lastName:e.target.value});
    }

    changeDOB =(e)=>{
        this.setState({dob:e.target.value});
    }

    changeStreet = (e) =>{
        this.setState({street:e.target.value});
    }

    changeState = (e) =>{
        this.setState({state:e.target.value});
    }

    changeCity = (e) =>{
        this.setState({city:e.target.value});
    }

    changeZipCode = (e) =>{
        this.setState({zipCode:e.target.value});
    }

    changePhoneNo = (e) =>{
        this.setState({phoneNo:e.target.value});
    }

    changeEmailAddress = (e) =>{
        this.setState({emailAddress:e.target.value});
    }


    addClick(){
        this.setState({
            modalTitle:"Add Patient",
            patientID:0,
            firstName:"",
            lastName:"" ,
            dob:"",
            street:"",
            state:"",
            city:"",
            zipCode:"",
            phoneNo:"",
            emailAddress:""   
        });
    }

    editClick(pat){
        this.setState({
            modalTitle:"Edit Patient",
            patientID:pat.patientID,
            firstName:pat.firstName,
            lastName:pat.lastName ,
            dob:pat.dob,
            street:pat.street,
            state:pat.state,
            city:pat.city,
            zipCode:pat.zipCode,
            phoneNo:pat.phoneNo,
            emailAddress:pat.emailAddress
        });
    }

    createClick(){
        if((!this.state.firstName)){
            alert('Please provide first name');
        }

        else if((this.state.firstName.match('[0-9]'))){
            alert('Please provide first name');
        }
        else if((!this.state.lastName) || (this.state.lastName.match('[0-9]'))){
            alert('Please provide valid last name');
        }
        else if((!this.state.street)){
            alert('Please provide a valid street name');
        }
        else if((!this.state.state)){
            alert('Please provide a valid state name');
        }
        else if((!this.state.city)){
            alert('Please provide a valid city name');
        }

    else if(!(this.state.dob.match('^(3[01]|[12][0-9]|0[1-9])-(1[0-2]|0[1-9])-[0-9]{4}$'))){
        alert('Please provide valid date in form of dd-mm-yyyy');
    }
    else if( !(this.state.phoneNo.toString().match('[0-9]{10}')) ){
            alert('Please provide valid phone number with 10 digits');
            
    } else if (!(this.state.zipCode.toString().match('[0-9]{5}'))){
        alert('Please provide valid zip code');
    }
    else if (!(this.state.emailAddress.match('[a-z0-9]+@[a-z]+\\.[a-z]{2,3}'))){
        alert('Please provide valid email id');
    }
    else{
        fetch(variables.API_URL+'patients',{
            method:'POST',
            headers:{
                'Accept':'application/json',
                'Content-Type':'application/json'
            },
            body:JSON.stringify({
                firstName:this.state.firstName,
                lastName:this.state.lastName ,
                dob:this.state.dob,
                street:this.state.street,
                state:this.state.state,
                city:this.state.city,
                zipCode:this.state.zipCode,
                phoneNo:this.state.phoneNo,
                emailAddress:this.state.emailAddress
            })
        })
        .then(res=>res.json())
        .then((result)=>{
            alert("Successfully added new patient!");
            this.refreshList();
        },(error)=>{
            alert('Failed');
        })
    }

        
    }

    updateClick(id){ 
       
       if((!this.state.firstName)){
            alert('Please provide first name');
        }

        else if((this.state.firstName.match('[0-9]'))){
            alert('Please provide first name');
        }
        else if((!this.state.lastName) || (this.state.lastName.match('[0-9]'))){
            alert('Please provide valid last name');
        }
        else if((!this.state.street)){
            alert('Please provide a valid street name');
        }
        else if((!this.state.state)){
            alert('Please provide a valid state name');
        }
        else if((!this.state.city)){
            alert('Please provide a valid city name');
        }

    else if(!(this.state.dob.match('^(3[01]|[12][0-9]|0[1-9])-(1[0-2]|0[1-9])-[0-9]{4}$'))){
        alert('Please provide valid date in form of dd-mm-yyyy');
    }
    else if( !(this.state.phoneNo.toString().match('[0-9]{10}')) ){
            alert('Please provide valid phone number with 10 digits');
            
    } else if (!(this.state.zipCode.toString().match('[0-9]{5}'))){
        alert('Please provide valid zip code');
    }
    else if (!(this.state.emailAddress.match('[a-z0-9]+@[a-z]+\\.[a-z]{2,3}'))){
        alert('Please provide valid email id');
    }
        
        else{
            fetch(variables.API_URL+'patients/'+id,{
                method:'PUT',
                headers:{
                    'Accept':'application/json',
                    'Content-Type':'application/json'
                },
                body:JSON.stringify({
                    firstName:this.state.firstName,
                    lastName:this.state.lastName ,
                    dob:this.state.dob,
                    street:this.state.street,
                    state:this.state.state,
                    city:this.state.city,
                    zipCode:this.state.zipCode,
                    phoneNo:this.state.phoneNo,
                    emailAddress:this.state.emailAddress
                })
            })
            .then(res=>res.json())
            .then((result)=>{
                alert("Succesfully modified record!");
                this.refreshList();
            },(error)=>{
                alert('Failed');
            })
        }
        
    }

    deleteClick(id){
        if(window.confirm('Are you sure you want to delete this patient record?')){
        fetch(variables.API_URL+'patients/'+id,{
            method:'DELETE',
            headers:{
                'Accept':'application/json',
                'Content-Type':'application/json'
            }
        })
        .then((res) => res.text())
        .then((text) => text.length ? JSON.parse(text) : {})
        .then((result)=>{
            alert("Successfully deleted the record!");
            this.refreshList();
        },(error)=>{
            alert(error);
        })
        }
    }


    render(){
        const{
            patients,
            modalTitle,
            patientID,
            firstName,
            lastName,
            dob,
            street,
            city,
            state,
            zipCode,
            phoneNo,
            emailAddress
            // getRowId = params => params.data.id
        }=this.state;
        return(
            <div>
                <button type="button"
                className="btn btn-primary m-2 float-end"
                data-bs-toggle="modal"
                data-bs-target="#exampleModal"
                onClick={()=>this.addClick()}>
                 Add Patient
                </button>
                <table className = "table table-striped">
                    <thead>
                        <th>
                        
<div className="flex-row">            
<input className="m-2"
onChange={this.changePatientIDFilter}
placeholder="Filter Id"/>

<button type="button" className="btn btn-light"
onClick={()=>this.sortResult('patientID',true)}>
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-arrow-down-square-fill" viewBox="0 0 16 16">
    <path d="M2 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H2zm6.5 4.5v5.793l2.146-2.147a.5.5 0 0 1 .708.708l-3 3a.5.5 0 0 1-.708 0l-3-3a.5.5 0 1 1 .708-.708L7.5 10.293V4.5a.5.5 0 0 1 1 0z"/>
    </svg>
</button>

<button type="button" className="btn btn-light"
onClick={()=>this.sortResult('patientID',false)}>
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-arrow-up-square-fill" viewBox="0 0 16 16">
    <path d="M2 16a2 2 0 0 1-2-2V2a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H2zm6.5-4.5V5.707l2.146 2.147a.5.5 0 0 0 .708-.708l-3-3a.5.5 0 0 0-.708 0l-3 3a.5.5 0 1 0 .708.708L7.5 5.707V11.5a.5.5 0 0 0 1 0z"/>
    </svg>
</button>

</div>
                            patient Id
                        </th>
                        <th>
                            First Name
                        </th>
                        <th>
                            Last Name
                        </th>
                        <th>
                            Date of Birth
                        </th>
                        <th>
                            Street
                        </th>
                        <th>
                            City
                        </th>
                        <th>
        <div className="flex-row">
        <input className="m-2"
            onChange={this.changePatientStateFilter}
            placeholder="Filter State"/>

            {/* <button type="button" className="btn btn-light"
            onClick={()=>this.sortResult('state',true)}>
                <svg xmlns="http://www.w3.org/2000/svg" width="30" height="16" fill="currentColor" className="bi bi-arrow-down-square-fill" viewBox="0 0 16 16">
                <path d="M2 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H2zm6.5 4.5v5.793l2.146-2.147a.5.5 0 0 1 .708.708l-3 3a.5.5 0 0 1-.708 0l-3-3a.5.5 0 1 1 .708-.708L7.5 10.293V4.5a.5.5 0 0 1 1 0z"/>
                </svg>
            </button>

            <button type="button" className="btn btn-light"
            onClick={()=>this.sortResult('state',false)}>
                <svg xmlns="http://www.w3.org/2000/svg" width="30" height="16" fill="currentColor" className="bi bi-arrow-up-square-fill" viewBox="0 0 16 16">
                <path d="M2 16a2 2 0 0 1-2-2V2a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H2zm6.5-4.5V5.707l2.146 2.147a.5.5 0 0 0 .708-.708l-3-3a.5.5 0 0 0-.708 0l-3 3a.5.5 0 1 0 .708.708L7.5 5.707V11.5a.5.5 0 0 0 1 0z"/>
                </svg>
            </button> */}
            </div>
                            State
                        </th>
                        <th>
                            ZipCode
                        </th>
                        <th>
                            Phone No
                        </th>
                        <th>
                            Email
                        </th>
                        <th>
                            Option
                        </th>
                    </thead>
                    <tbody>
                        {patients.map(pat=>
                            <tr key ={pat.patientID}> 
                            <td>{pat.patientID}</td>
                            <td>{pat.firstName}</td>
                            <td>{pat.lastName}</td>
                            <td>{pat.dob}</td>
                            <td>{pat.street}</td>
                            <td>{pat.city}</td>
                            <td>{pat.state}</td>
                            <td>{pat.zipCode}</td>
                            <td>{pat.phoneNo}</td>
                            <td>{pat.emailAddress}</td>
                            <td>
                                <button type="button" 
                                className="btn btn-light mr-1"
                                data-bs-toggle="modal"
                                data-bs-target="#exampleModal"
                                onClick={()=>this.editClick(pat)}>
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pencil-square" viewBox="0 0 16 16">
                                    <path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z"/>
                                    <path fillRule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5v11z"/>
                                    </svg>
                                </button>
                                <button type="button" 
                                className="btn btn-light mr-1"
                                onClick={()=>this.deleteClick(pat.patientID)}>
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash-fill" viewBox="0 0 16 16">
                                    <path d="M2.5 1a1 1 0 0 0-1 1v1a1 1 0 0 0 1 1H3v9a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2V4h.5a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1H10a1 1 0 0 0-1-1H7a1 1 0 0 0-1 1H2.5zm3 4a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-1 0v-7a.5.5 0 0 1 .5-.5zM8 5a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-1 0v-7A.5.5 0 0 1 8 5zm3 .5v7a.5.5 0 0 1-1 0v-7a.5.5 0 0 1 1 0z"/>
                                    </svg>
                                </button>
                            </td>
                            </tr>)}
                    </tbody>
                </table>

<div className="modal fade" id="exampleModal" tabIndex="-1" aria-hidden="true">
<div className="modal-dialog modal-lg modal-dialog-centered">
<div className="modal-content">
   <div className="modal-header">
       <h5 className="modal-title">{modalTitle}</h5>
       <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"
       ></button>
   </div>

   <div className="modal-body">
       <div className="mb-3">
        <span className="input-group-text">First Name</span>
        <input type="text" className="form-control"
        value={firstName}
        onChange={this.changeFirstName}/>
        <br></br>
        <span className="input-group-text">Last Name</span>
        <input type="text" className="form-control"
        value={lastName}
        onChange={this.changeLastName}/>
        <br></br>
        <span className="input-group-text">DOB (dd-mm-yyyy)</span>
        <input type="text" className="form-control"
        value={dob}
        onChange={this.changeDOB}/>
        <br></br>
        <span className="input-group-text">Street</span>
        <input type="text" className="form-control"
        value={street}
        onChange={this.changeStreet}/>
        <br></br>
        <span className="input-group-text">City</span>
        <input type="text" className="form-control"
        value={city}
        onChange={this.changeCity}/>
        <br></br>
        <span className="input-group-text">State</span>
        <input type="text" className="form-control"
        value={state}
        onChange={this.changeState}/>
        <br></br>
        <span className="input-group-text">Zip Code</span>
        <input type="text" className="form-control"
        value={zipCode}
        onChange={this.changeZipCode}/>
        <br></br>
        <span className="input-group-text">Phone No</span>
        <input type="text" className="form-control"
        value={phoneNo}
        onChange={this.changePhoneNo}/>
        <br></br>
        <span className="input-group-text">Email Address</span>
        <input type="text" className="form-control"
        value={emailAddress}
        onChange={this.changeEmailAddress}/>
       </div>

        {patientID==0?
        <button type="button"
        className="btn btn-primary float-start"
        onClick={()=>this.createClick()}
        >Create</button>
        :null}

        {patientID!=0?
        <button type="button"
        className="btn btn-primary float-start"
        onClick={()=>this.updateClick(patientID)}
        >Update</button>
        :null}

   </div>

</div>
</div> 
</div>
            </div>
        )
    }
}