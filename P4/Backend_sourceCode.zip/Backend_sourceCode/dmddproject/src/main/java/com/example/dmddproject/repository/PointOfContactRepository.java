package com.example.dmddproject.repository;

import com.example.dmddproject.model.Patient;
import com.example.dmddproject.model.PointOfContact;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface PointOfContactRepository extends JpaRepository<PointOfContact,Long> {
    List<PointOfContact> findByFirstNameContaining(String first_name);
}
