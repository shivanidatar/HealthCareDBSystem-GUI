package com.example.dmddproject.controller;

import com.example.dmddproject.model.Patient;
import com.example.dmddproject.model.PointOfContact;
import com.example.dmddproject.repository.PatientRepository;
import com.example.dmddproject.repository.PointOfContactRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/api")
public class PointOfContactController {

    @Autowired
    PointOfContactRepository pointOfContactRepository;

    @GetMapping("/contacts")
    public ResponseEntity<List<PointOfContact>> getAllPatients(@RequestParam(required = false) String firstName) {
        try {
            List<PointOfContact> contacts = new ArrayList<PointOfContact>();

            if (firstName == null)
                pointOfContactRepository.findAll().forEach(contacts::add);
            else
                pointOfContactRepository.findByFirstNameContaining(firstName).forEach(contacts::add);

            if (contacts.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(contacts, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

}
