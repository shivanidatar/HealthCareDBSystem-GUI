package com.example.dmddproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DmddprojectApplicationTests {

    @Test
    void contextLoads() {
    }

}
